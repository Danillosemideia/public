
function navegateTo(page) {
    window.location.href = page;
}